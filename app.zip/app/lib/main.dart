import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' show get;
import 'package:flutter/material.dart';

void main() {
  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Map<String, String> characterDetails = {};

  void generateCharacter() async {
    showDialog(
      context: context,
      barrierDismissible:
          false, //prevents the closing of the dialogue box when outside is clicked
      builder: (BuildContext context) {
        return const Center(
          child: CircularProgressIndicator(),
        );
      },
    );

    var characterRequest =
        await get(Uri.parse('https://api.genshin.dev/characters/'));
    var characters = jsonDecode(characterRequest.body);
    characters.toList();
    int randomIndex = Random().nextInt(characters.length);
    var detailRequest = await get(Uri.parse(
        'https://api.genshin.dev/characters/${characters[randomIndex]}'));
    var details = jsonDecode(detailRequest.body);
    var instance = ImageModel.fromJson(details);
    characterDetails = instance.createMap(characters[randomIndex]);
    setState(() {
      characterDetails = instance.createMap(characters[randomIndex]);
      Timer(const Duration(seconds: 3), () {
        Navigator.pop(context);
      });
    });
  }

  Widget generateText(String header, String content) {
    return RichText(
      text: TextSpan(
        style: const TextStyle(
          height: 1.25,
          fontSize: 17,
          decoration: TextDecoration.none,
        ),
        children: [
          TextSpan(
            text: header,
            style: const TextStyle(
              fontFamily: 'Raleway Medium',
              color: Color(0xFF686854),
            ),
          ),
          TextSpan(
            text: content,
            style: const TextStyle(
              fontFamily: 'Raleway Light',
              color: Color(0xFFFFF4D1),
            ),
          ),
        ],
      ),
    );
  }

  Widget showDescription() {
    return SizedBox(
      height: 88,
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: generateText(
                  'Description: ', '${characterDetails['Description']}'),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFF2C2C24),
        body: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                characterDetails.isEmpty
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            width: 350,
                            height: 550,
                            decoration: const BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage('images/start.png'),
                              ),
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.fromLTRB(30, 30, 30, 0),
                            child: const Text(
                              'Meet a Genshin Character by Rolling an Intertwined Fate',
                              style: TextStyle(
                                fontFamily: 'Raleway Medium',
                                fontSize: 20,
                                color: Color(0xFFFFF4D1),
                              ),
                            ),
                          ),
                        ],
                      )
                    : Container(
                        margin: const EdgeInsets.all(50),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Card(
                              margin: const EdgeInsets.only(bottom: 10),
                              child: Image.network(
                                'https://api.genshin.dev/characters/${characterDetails['Code']}/card',
                                width: 250,
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                generateText(
                                    'Name: ', '${characterDetails['Name']}'),
                                generateText('Vision: ',
                                    '${characterDetails['Vision']}'),
                                generateText('Weapon: ',
                                    '${characterDetails['Weapon']}'),
                                showDescription(),
                              ],
                            ),
                          ],
                        ),
                      ),
              ],
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: InkWell(
                onTap: () => {generateCharacter()},
                child: Container(
                  margin: const EdgeInsets.only(bottom: 50),
                  width: 80,
                  height: 80,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('images/button.png'),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ImageModel {
  late String name;
  late String vision;
  late String weapon;
  late String description;

  //ImageModel(this.name, this.vision, this.weapon, this.description);

  ImageModel.fromJson(parsedJson) {
    name = parsedJson['name']!;
    vision = parsedJson['vision']!;
    weapon = parsedJson['weapon']!;
    description = parsedJson['description']!;
  }

  createMap(String code) {
    return {
      "Code": code,
      "Name": name,
      "Vision": vision,
      "Weapon": weapon,
      "Description": description
    };
  }
}
